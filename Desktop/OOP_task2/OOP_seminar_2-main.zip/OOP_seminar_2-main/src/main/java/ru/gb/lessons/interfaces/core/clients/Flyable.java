package ru.gb.lessons.interfaces.core.clients;

public interface Flyable {
    int fly();
}
