package ru.gb.lessons.interfaces.core.clients;

public interface Some1 extends Some {
    
}
