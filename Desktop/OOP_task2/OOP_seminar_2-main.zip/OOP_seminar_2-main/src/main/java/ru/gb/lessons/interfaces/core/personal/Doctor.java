package ru.gb.lessons.interfaces.core.personal;

public class Doctor {
}
