package ru.gb.lessons.interfaces.core.clients;

public interface Runnable {
    int run();
}
