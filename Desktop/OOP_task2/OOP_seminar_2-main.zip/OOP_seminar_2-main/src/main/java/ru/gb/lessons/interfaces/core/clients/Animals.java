package ru.gb.lessons.interfaces.core.clients;

public interface Animals {
    String getClassName();
}
